package bg.sofia.uni.fmi.mjt.spotify.common.models;

public record CommandResponse(String message, boolean isSuccessful) {

}
