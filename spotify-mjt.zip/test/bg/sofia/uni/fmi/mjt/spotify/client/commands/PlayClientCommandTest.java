package bg.sofia.uni.fmi.mjt.spotify.client.commands;

public class PlayClientCommandTest {
}
